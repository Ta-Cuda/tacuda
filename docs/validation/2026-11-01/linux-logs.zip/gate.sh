#!/usr/bin/env bash
# Linux GPU release gate for tacuda 0.8.0 (source a5c8f35, LF archive).
# Same steps as the 2026-10-14 gate (docs/validation/2026-10-14/linux-logs.zip),
# plus a batch-path TA-Lib sweep of the fixed tree and of a control build of
# the parent without the *_batch_d stream-0 fix (a23d4b7).
# Deviations from CI: user-local CUDA 12.8 has no libcudart_static, so cudart
# is shared; vLLM holds ~21 of 23 GB VRAM on this host during the run; Node 22
# and the .NET 8 SDK are reused from the 2026-10-14 gate directory.
# Every step logs to logs/<step>.log and appends "<step>\t<rc>\t<secs>" to results.tsv;
# a failing step does not stop the following ones.
set -u
G=/home/user/work/tacuda-v080-gate-20261101
O=/home/user/work/tacuda-v080-gate-20261014
SRC=$G/src
B=$G/build
SRCC=$G/src-control
BC=$G/build-control
LOG=$G/logs
RES=$G/results.tsv
mkdir -p "$LOG"
: > "$RES"
: > "$LOG/progress.log"

export CUDA_HOME=$HOME/cuda-dev/cu128/usr/local/cuda-12.8
export PATH=$CUDA_HOME/bin:$PATH
export LD_LIBRARY_PATH=$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}
# User-local toolkit is not on the default linker search path (CI's container is).
export LIBRARY_PATH=$CUDA_HOME/lib64:${LIBRARY_PATH:-}
export PATH=$HOME/tools/cmake-3.29.6-linux-x86_64/bin:$PATH
# Host has node 18 without npm; CI uses setup-node 22.
export PATH=$O/node22/bin:$PATH
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

step() {
  local name=$1; shift
  local t0; t0=$(date +%s)
  echo "[$(date +%T)] START $name" >> "$LOG/progress.log"
  ( set -eo pipefail; "$@" ) > "$LOG/$name.log" 2>&1
  local rc=$?
  local dt=$(( $(date +%s) - t0 ))
  printf '%s\t%s\t%ss\n' "$name" "$rc" "$dt" >> "$RES"
  echo "[$(date +%T)] END $name rc=$rc ${dt}s" >> "$LOG/progress.log"
  return 0
}

s_env() {
  date -Is; hostname; uname -r; grep PRETTY /etc/os-release
  nvidia-smi --query-gpu=name,driver_version,memory.used,memory.total --format=csv
  nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv
  nvcc --version | tail -2; gcc --version | head -1; cmake --version | head -1; ninja --version
  python3 --version; node --version; npm --version
  sha256sum "$G/tacuda-a5c8f35-lf.tar.gz" "$G/tacuda-a23d4b7-lf.tar.gz"
}
s_extract() {
  rm -rf "$SRC" "$B" "$SRCC" "$BC"
  tar -xzf "$G/tacuda-a5c8f35-lf.tar.gz" -C "$G"
  tar -xzf "$G/tacuda-a23d4b7-lf.tar.gz" -C "$G"
  ls "$SRC"; diff -rq "$SRCC" "$SRC" || true
}
s_venv() {
  rm -rf "$G/venv"
  python3 -m venv "$G/venv"
  "$G/venv/bin/python" -m pip install -q --upgrade pip
  "$G/venv/bin/python" -m pip install -r "$SRC/tests/requirements-reference.txt"
  "$G/venv/bin/python" -c "import talib, numpy; assert len(talib.get_functions()) == 161; print(talib.__version__, talib.__ta_version__, numpy.__version__)"
}
s_configure() {
  cmake -S "$SRC" -B "$B" -G Ninja -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CUDA_COMPILER="$CUDA_HOME/bin/nvcc" -DCMAKE_CUDA_ARCHITECTURES=86 \
    -DBUILD_TESTING=ON -DTACUDA_ENABLE_ASAN_TEST=ON \
    -DCMAKE_CUDA_FLAGS=--cudart=shared -DCMAKE_CUDA_RUNTIME_LIBRARY=Shared \
    -DPython3_EXECUTABLE="$G/venv/bin/python"
}
s_build() { cmake --build "$B" -j 6; }
s_asan() { "$B/stream_lifetime_sanitizer"; }
s_exports() { python3 "$SRC/scripts/check_dll_exports.py" "$B/libtacuda.so"; }

# Reference env exactly as CI: venv first on PATH (tests shell out to python3 + talib).
gpu_env() {
  export PATH="$G/venv/bin:$PATH"
  export TACUDA_LIBRARY="$B/libtacuda.so"
  export PYTHONPATH="$SRC/bindings/python"
}
s_ctest() {
  gpu_env
  python3 -c "import talib; print('python3 ->', talib.__version__)"
  ctest --test-dir "$B" --output-on-failure --output-junit "$G/ctest.xml"
}
s_py_pipeline() { gpu_env; cd "$SRC/bindings/python" && python3 test_pipeline.py; }
s_corpus() { gpu_env; cd "$SRC/benchmarks" && python3 differential_corpus.py --json "$G/corpus.json"; }
s_stream_corpus() { gpu_env; cd "$SRC/benchmarks" && python3 streaming_corpus.py --json "$G/streaming_corpus.json"; }
s_batch_quick() { gpu_env; python3 "$SRC/benchmarks/benchmark_batch_api.py" --quick; }
s_node() { gpu_env; cd "$SRC/bindings/nodejs" && npm install --no-audit --no-fund && node test_pipeline.js; }
# CI's gpu-tests job installs only the 8.0 SDK; reuse the one installed for the previous gate.
s_dotnet8() { "$O/dotnet/dotnet" --list-sdks; }
s_csharp() {
  gpu_env
  export DOTNET_ROOT="$O/dotnet" PATH="$O/dotnet:$PATH"
  export LD_LIBRARY_PATH="$B:$LD_LIBRARY_PATH"
  cd "$SRC/bindings/csharp/ConsoleExample"
  dotnet run -c Release -f net8.0 -- --pipeline
  dotnet run -c Release -f net8.0 --no-build -- --test
}

# Extra evidence for the stream-0 fix: every corpus spec through its *_batch_d
# family on stream 0 while the input is still being produced on the legacy
# stream. Exit 1 is expected for both: the fixed tree fails only the documented
# Hilbert specs, the control fails broadly.
s_batch_talib() {
  gpu_env
  cd "$G" && python3 batch_corpus_vs_talib.py "$SRC/benchmarks" || true
}
s_control_build() {
  cmake -S "$SRCC" -B "$BC" -G Ninja -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CUDA_COMPILER="$CUDA_HOME/bin/nvcc" -DCMAKE_CUDA_ARCHITECTURES=86 \
    -DBUILD_TESTING=OFF -DTACUDA_BUILD_OPTIMIZER=OFF \
    -DCMAKE_CUDA_FLAGS=--cudart=shared -DCMAKE_CUDA_RUNTIME_LIBRARY=Shared
  cmake --build "$BC" -j 6 --target tacuda
}
s_batch_talib_control() {
  export PATH="$G/venv/bin:$PATH"
  export TACUDA_LIBRARY="$BC/libtacuda.so"
  export PYTHONPATH="$SRCC/bindings/python"
  cd "$G" && python3 batch_corpus_vs_talib.py "$SRCC/benchmarks" || true
}

step env s_env
step extract s_extract
step venv s_venv
step configure s_configure
step build s_build
step asan s_asan
step exports s_exports
step ctest s_ctest
step py_pipeline s_py_pipeline
step corpus s_corpus
step stream_corpus s_stream_corpus
step batch_quick s_batch_quick
step node s_node
step dotnet8 s_dotnet8
step csharp s_csharp
step batch_talib s_batch_talib
step control_build s_control_build
step batch_talib_control s_batch_talib_control
echo "[$(date +%T)] GATE DONE" >> "$LOG/progress.log"
