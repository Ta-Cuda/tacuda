#!/usr/bin/env python3
"""Batch-path TA-Lib sweep over the differential corpus.

Every corpus spec whose TaCuda side is ONE host call with a *_batch_d
counterpart is re-run through ct_<family>_batch_d on stream 0, while the
inputs are still being produced on the legacy default stream (a host callback
holds the stream, then a D2D copy writes the real input over a NaN-filled
buffer). Each batch row is fed back through the spec's own post-processing
and judged by the corpus oracle against TA-Lib; rows are also compared
bitwise with the single-series host call.

Usage: python batch_corpus_vs_talib.py <benchmarks_dir> [--hold-ms 20] [--max-concurrency 4]
"""
import argparse
import ctypes
import math
import sys
import time
from collections import defaultdict
from contextlib import contextmanager

import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("benchmarks_dir")
ap.add_argument("--hold-ms", type=float, default=20.0)
ap.add_argument("--max-concurrency", type=int, default=4)
ap.add_argument("--min-rows", type=int, default=8)
args = ap.parse_args()
sys.path.insert(0, args.benchmarks_dir)

import tacuda  # noqa: E402
import talib  # noqa: E402
from talib_compare_helpers import build_specs, compare_arrays, compare_discrete  # noqa: E402
from differential_corpus import build_corpus  # noqa: E402

lib_path = [l.split()[-1] for l in open("/proc/self/maps") if "libtacuda" in l][0]
print(f"libtacuda: {lib_path}")

# Same shared runtime instance tacuda is linked against.
cudart = ctypes.CDLL("libcudart.so.12")
cudart.cudaMalloc.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_size_t]
cudart.cudaFree.argtypes = [ctypes.c_void_p]
cudart.cudaMemset.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t]
cudart.cudaMemcpy.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
cudart.cudaMemcpyAsync.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int, ctypes.c_void_p]
cudart.cudaDeviceSynchronize.argtypes = []
HOSTFN = ctypes.CFUNCTYPE(None, ctypes.c_void_p)
cudart.cudaLaunchHostFunc.argtypes = [ctypes.c_void_p, HOSTFN, ctypes.c_void_p]
H2D, D2H, D2D = 1, 2, 3
LEGACY = None  # stream 0 through the plain (non-_ptsz) runtime symbols = legacy default stream


def ck(err, what):
    if err != 0:
        raise RuntimeError(f"{what} failed: cudaError {err}")


def hold(_):
    time.sleep(args.hold_ms / 1000.0)


HOLD_CB = HOSTFN(hold)  # keep a reference for the lifetime of the process


class DevBuf:
    def __init__(self, nbytes):
        self.p = ctypes.c_void_p()
        self.n = nbytes
        ck(cudart.cudaMalloc(ctypes.byref(self.p), nbytes), "cudaMalloc")

    def free(self):
        cudart.cudaFree(self.p)


SPEC = tacuda._SPEC
BATCH_FIXED = {"seriesLen", "numSeries", "maxConcurrency", "stream"}
FAMILIES = sorted(n[: -len("_batch_d")] for n in SPEC
                  if n.endswith("_batch_d") and hasattr(tacuda, n[: -len("_batch_d")]))


# Wrappers are installed BEFORE build_specs: some specs (candlesticks) capture
# the tacuda function object at build time instead of looking it up per call.
_STATE = {"handler": None, "depth": 0}


def _install_wrappers():
    def make(f, orig):
        def fn(*a, **k):
            h = _STATE["handler"]
            if h is None or _STATE["depth"]:
                return orig(*a, **k)  # pass-through / nested call inside a wrapper
            _STATE["depth"] += 1
            try:
                return h(f, orig, a, k)
            finally:
                _STATE["depth"] -= 1
        return fn
    for f in FAMILIES:
        setattr(tacuda, f, make(f, getattr(tacuda, f)))


_install_wrappers()

# Batch scalars the host wrapper does not take, with the value the host path
# uses internally (and the corpus asks TA-Lib for).
SCALAR_DEFAULTS = {"dMaType": 0}  # STOCHF fast %D: CT_MA_SMA, TA-Lib fastd_matype=0


@contextmanager
def intercept(handler):
    _STATE["handler"] = handler
    try:
        yield
    finally:
        _STATE["handler"] = None


def plan(fam, a, k):
    """Map a recorded host call onto the batch_d signature."""
    b = SPEC[fam + "_batch_d"]
    n_in = len(b.inputs)
    arrays = a[:n_in]
    if len(arrays) != n_in or not all(isinstance(x, np.ndarray) for x in arrays):
        return None, "host inputs are not plain arrays"
    k = dict(k)
    dtype = k.pop("dtype", "float32")
    if str(np.dtype(dtype)) != "float32":
        return None, f"dtype={dtype}"
    k.pop("stream", None)
    names = [s.name for s in b.scalars if s.name not in BATCH_FIXED]
    rest = list(a[n_in:])
    vals = []
    for i, name in enumerate(names):
        if i < len(rest):
            vals.append(rest[i])
        elif name in k:
            vals.append(k.pop(name))
        elif name in SCALAR_DEFAULTS:
            vals.append(SCALAR_DEFAULTS[name])
        else:
            return None, f"scalar '{name}' not given by the host call"
    if len(rest) > len(names) or k:
        return None, f"host call has extra args {rest[len(names):]} {k}"
    return (fam, [np.ascontiguousarray(x, dtype=np.float32) for x in arrays],
            dict(zip(names, vals)), len(b.outputs)), None


def run_batch(fam, mats, vals, n_out):
    S, T = mats[0].shape
    nbytes = S * T * 4
    stage = [DevBuf(nbytes) for _ in mats]
    dins = [DevBuf(nbytes) for _ in mats]
    douts = [DevBuf(nbytes) for _ in range(n_out)]
    try:
        for st, m in zip(stage, mats):
            ck(cudart.cudaMemcpy(st.p, m.ctypes.data, nbytes, H2D), "upload")
        for d in dins:
            ck(cudart.cudaMemset(d.p, 0xFF, nbytes), "memset in")      # NaN
        for d in douts:
            ck(cudart.cudaMemset(d.p, 0x7F, nbytes), "memset out")     # 3.39e38 sentinel
        ck(cudart.cudaDeviceSynchronize(), "sync")
        # Producer still in flight on the legacy default stream:
        ck(cudart.cudaLaunchHostFunc(LEGACY, HOLD_CB, None), "hold")
        for d, st in zip(dins, stage):
            ck(cudart.cudaMemcpyAsync(d.p, st.p, nbytes, D2D, LEGACY), "produce")
        fn = getattr(tacuda, fam + "_batch_d")
        fn(*[d.p.value for d in dins], *[o.p.value for o in douts], seriesLen=T,
           numSeries=S, maxConcurrency=args.max_concurrency, stream=0, **vals)
        ck(cudart.cudaDeviceSynchronize(), "sync after batch")
        outs = []
        for o in douts:
            h = np.empty((S, T), dtype=np.float32)
            ck(cudart.cudaMemcpy(h.ctypes.data, o.p, nbytes, D2H), "download")
            outs.append(h)
        return outs
    finally:
        for b in stage + dins + douts:
            b.free()


def as_like(template, outs, r):
    rows = [o[r].copy() for o in outs]
    if isinstance(template, tuple):
        return tuple(rows)
    return rows[0]


def main():
    specs = build_specs(tacuda, talib)
    corpus = build_corpus(4096)
    print(f"specs: {len(specs)}, datasets: {len(corpus)}, batch_d families: {len(FAMILIES)}, "
          f"hold {args.hold_ms} ms, maxConcurrency {args.max_concurrency}, stream 0")

    skipped = defaultdict(list)
    cells = 0
    fails = []
    bit_equal = 0
    bit_rows = 0
    max_host_diff = 0.0
    covered = set()
    talib_cache = {}
    t0 = time.time()

    for spec in specs:
        datasets = [d for d in corpus if d not in getattr(spec, "skip_datasets", ())]
        # 1. record the host call per dataset
        rec = {}
        reason = None
        for ds in datasets:
            calls = []

            def recorder(f, orig, a, k):
                r = orig(*a, **k)
                calls.append((f, a, k, r))
                return r
            with intercept(recorder):
                spec.tacuda_fn(corpus[ds])
            if len(calls) != 1:
                reason = f"{len(calls)} TaCuda calls with a batch_d counterpart"
                break
            p, why = plan(*calls[0][:3])
            if p is None:
                reason = why
                break
            rec[ds] = (p, calls[0][3])
        if reason:
            skipped[reason].append(spec.name)
            continue
        fam = next(iter(rec.values()))[0][0]
        covered.add(spec.name)

        # 2. batch per series length, rows tiled to >= min_rows
        by_len = defaultdict(list)
        for ds in datasets:
            by_len[rec[ds][0][1][0].size].append(ds)
        for T, dss in by_len.items():
            reps = math.ceil(args.min_rows / len(dss))
            row_ds = dss * reps
            vals = rec[dss[0]][0][2]
            assert all(rec[d][0][2] == vals for d in dss), "scalars differ across datasets"
            n_in = len(rec[dss[0]][0][1])
            mats = [np.stack([rec[d][0][1][j] for d in row_ds]) for j in range(n_in)]
            outs = run_batch(fam, mats, vals, rec[dss[0]][0][3])

            for r, ds in enumerate(row_ds):
                host = rec[ds][1]
                row = as_like(host, outs, r)
                # bitwise vs the single-series host call
                hs = host if isinstance(host, tuple) else (host,)
                bs = row if isinstance(row, tuple) else (row,)
                same = all(np.array_equal(np.asarray(h, np.float32), b, equal_nan=True) for h, b in zip(hs, bs))
                bit_rows += 1
                bit_equal += same
                if not same:
                    for h, b in zip(hs, bs):
                        h = np.asarray(h, np.float64); b = b.astype(np.float64)
                        m = ~(np.isnan(h) | np.isnan(b))
                        if m.any():
                            max_host_diff = max(max_host_diff, float(np.max(np.abs(h[m] - b[m]) / np.maximum(1, np.maximum(np.abs(h[m]), np.abs(b[m]))))))
                # TA-Lib oracle on the batch row, through the spec's own post-processing
                with intercept(lambda f, orig, a, k: row):
                    got = spec.tacuda_fn(corpus[ds])
                key = (spec.name, ds)
                if key not in talib_cache:
                    talib_cache[key] = spec.talib_fn(corpus[ds])
                ref = talib_cache[key]
                got_t = got if isinstance(got, tuple) else (got,)
                ref_t = ref if isinstance(ref, tuple) else (ref,)
                cmp = compare_discrete if getattr(spec, "discrete", False) else compare_arrays
                ok = len(got_t) == len(ref_t)
                md = 0.0
                nm = 0
                for g, rr in zip(got_t, ref_t):
                    ok_i, md_i, _, nm_i = cmp(np.asarray(g, np.float64), np.asarray(rr, np.float64), spec.tolerance)
                    ok &= ok_i
                    md = max(md, md_i if np.isfinite(md_i) else float("inf"))
                    nm += max(nm_i, 0)
                cells += 1
                if not ok:
                    fails.append((spec.name, fam, ds, r, md, nm))

    dt = time.time() - t0
    specs_fail = sorted({f[0] for f in fails})
    print(f"covered specs via *_batch_d: {len(covered)}/{len(specs)}")
    print(f"batch rows vs TA-Lib (corpus oracle): {cells - len(fails)}/{cells} pass; "
          f"specs green {len(covered) - len(specs_fail)}/{len(covered)}")
    print(f"batch rows bit-identical to single-series host call: {bit_equal}/{bit_rows}"
          + (f" (max rel diff otherwise {max_host_diff:.3g})" if bit_equal != bit_rows else ""))
    print(f"elapsed {dt:.1f}s")
    for reason, names in sorted(skipped.items()):
        print(f"  not covered ({len(names)}): {reason}: {', '.join(names[:12])}{' ...' if len(names) > 12 else ''}")
    if fails:
        rows0 = sum(1 for f in fails if f[3] == 0)
        print(f"  FAIL cells: {len(fails)} (row 0: {rows0}), grouped by (spec, dataset):")
        grouped = defaultdict(list)
        for f in fails:
            grouped[(f[0], f[1], f[2])].append(f)
        for (name, fam, ds), fs in sorted(grouped.items()):
            print(f"    {name:22s} via {fam}_batch_d  {ds:8s} rows {[f[3] for f in fs]}  "
                  f"maxDiff={max(f[4] for f in fs):.3g} nanMismatch={max(f[5] for f in fs)}")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
