@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d J:\codex-audits\tacuda-20261007-263f99b
cl /nologo /std:c++17 /EHsc /fsanitize=address /Zi /MD /I source\include /I "%CUDA_PATH%\include" asan-repro.cpp source\src\api\api_stream.cpp source\src\utils\ErrorState.cpp /Fe:asan-repro.exe > logs\asan-build.log 2>&1
if errorlevel 1 exit /b 2
asan-repro.exe > logs\asan-control.log 2>&1
if errorlevel 1 exit /b 3
asan-repro.exe freed > logs\asan-uaf.log 2>&1
set code=%errorlevel%
echo %code% > logs\asan-uaf-exit.txt
exit /b 0

