import ctypes, hashlib, json, pathlib, re, sys, zipfile
import numpy, talib
root = pathlib.Path(__file__).resolve().parent
source = root / "source"
report = {"python":sys.version, "numpy":numpy.__version__, "talib":talib.__version__, "talib_native":str(talib.__ta_version__), "talib_functions":len(talib.get_functions())}
report["talib_binaries"] = [str(p) for p in pathlib.Path(talib.__file__).parent.parent.glob("ta_lib.libs/*.dll")] + [str(p) for p in pathlib.Path(talib.__file__).parent.glob("*.dll")]
dll=source/"build"/"tacuda.dll"
if dll.exists():
    import tacuda
    report["native_version"]=tacuda.version()
    report["loaded_native"]=tacuda._lib._name
    report["sha256"]=hashlib.sha256(dll.read_bytes()).hexdigest()
    report["sma_tail"]=tacuda.sma(numpy.arange(32,dtype=numpy.float32),5)[-3:].tolist()
    names=set()
    for filename in ("tacuda.h","tacuda_device.h","tacuda_stream.h"):
        names.update(re.findall(r"CTAPI_EXPORT[ \t]+(?:[\w]+[ \t*]+)+(ct_\w+)[ \t]*\(",(source/"include"/filename).read_text()))
    missing=[]
    for name in sorted(names):
        try: getattr(tacuda._lib,name)
        except AttributeError: missing.append(name)
    report["required_exports"]=len(names)
    report["missing_exports"]=missing
with zipfile.ZipFile(root/"source.zip") as z:
    changes=[n for n in z.namelist() if not n.endswith("/") and (not (source/n).exists() or z.read(n)!=(source/n).read_bytes())]
report["source_changes"]=changes
print(json.dumps(report,indent=2))
(root/"logs"/"verification.json").write_text(json.dumps(report,indent=2),encoding="utf8")
if changes or report.get("missing_exports"): sys.exit(1)
