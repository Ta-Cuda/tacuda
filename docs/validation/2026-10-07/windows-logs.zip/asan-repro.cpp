#include "tacuda_stream.h"
#include <cstdio>
int main(int argc, char**) {
  ctStream_t* s = nullptr;
  if (ct_sma_stream_create(3, &s) != CT_STATUS_SUCCESS) return 10;
  float in[] = {1,2,3,4};
  float out[4];
  if (ct_sma_stream_append(s, in, 4, out) != CT_STATUS_SUCCESS) return 11;
  if (out[2] != 2 || out[3] != 3) return 12;
  if (ct_stream_destroy(s) != CT_STATUS_SUCCESS) return 13;
  if (argc > 1) return ct_stream_reset(s) == CT_STATUS_INVALID_ARGUMENT ? 0 : 14;
  std::puts("control PASS: SMA and normal destroy");
  return 0;
}
