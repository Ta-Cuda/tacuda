﻿$ErrorActionPreference='Stop'
$auditRoot='J:\codex-audits\tacuda-20261007-263f99b'
$source="$auditRoot\source"
$logs="$auditRoot\logs"
$results=New-Object System.Collections.Generic.List[object]
function Run-Step([string]$Name,[string]$Exe,[string[]]$Arguments,[string]$Cwd=$source) {
    Set-Content "$auditRoot\phase.txt" $Name
    $start=[DateTime]::UtcNow
    Push-Location $Cwd
    try {
        $ErrorActionPreference='Continue'
        & $Exe @Arguments *> "$logs\$Name.log"
        $code=$LASTEXITCODE
    } finally { Pop-Location }
    if($null -eq $code){$code=1}
    $results.Add([pscustomobject]@{step=$Name;exitCode=$code;startedUtc=$start.ToString('o');durationSeconds=[Math]::Round(([DateTime]::UtcNow-$start).TotalSeconds,2)})
    $results | ConvertTo-Json -Depth 4 | Set-Content "$logs\results.json"
    return $code
}
try {
    nvidia-smi > "$logs\gpu.txt"
    cmd /c ver > "$logs\os.txt"
    nvcc --version > "$logs\nvcc.txt"
    cmd.exe /c "cl 2>&1" | Out-File "$logs\msvc.txt"
    cmake --version > "$logs\cmake.txt"
    dotnet --list-sdks > "$logs\dotnet.txt"
    if((Run-Step 'venv' 'C:\Program Files\Python312\python.exe' @('-m','venv',"$auditRoot\venv")) -ne 0){throw 'venv failed'}
    $py="$auditRoot\venv\Scripts\python.exe"
    $env:PATH="$auditRoot\venv\Scripts;$source\build;$env:PATH"
    $env:PYTHONIOENCODING='utf-8'
    $env:PYTHONUNBUFFERED='1'
    $env:TACUDA_LIBRARY="$source\build\tacuda.dll"
    $env:PYTHONPATH="$source\bindings\python"
    if((Run-Step 'python-dependencies' $py @('-m','pip','install','numpy==2.2.6','TA-Lib==0.8.1')) -ne 0){throw 'dependencies failed'}
    [void](Run-Step 'python-preflight' $py @('-c','import sys,numpy,talib; print(sys.executable); print("numpy",numpy.__version__); print("talib",talib.__version__,talib.__ta_version__); print("functions",len(talib.get_functions()))'))
    if((Run-Step 'configure' 'cmake.exe' @('-S','.','-B','build','-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CUDA_ARCHITECTURES=86','-DBUILD_TESTING=ON',"-DPython3_EXECUTABLE=$py","-DCMAKE_CUDA_COMPILER=$env:CUDA_PATH/bin/nvcc.exe","-DCUDAToolkit_ROOT=$env:CUDA_PATH")) -ne 0){throw 'configure failed'}
    if((Run-Step 'build' 'cmake.exe' @('--build','build','-j','4')) -ne 0){throw 'build failed'}
    Get-FileHash "$source\build\tacuda.dll" -Algorithm SHA256 | Format-List > "$logs\native-sha256.txt"
    [void](Run-Step 'exports-smoke' $py @('scripts/check_dll_exports.py','build/tacuda.dll'))
    [void](Run-Step 'native-preflight' $py @('-c','import tacuda,numpy as np; print("native",tacuda.version()); print("library",tacuda._lib._name); print("SMA",tacuda.sma(np.arange(32,dtype=np.float32),5)[-3:])'))
    [void](Run-Step 'ctest' 'ctest.exe' @('--test-dir','build','--output-on-failure','--parallel','1','--timeout','180','--output-junit',"$logs\ctest.xml"))
    [void](Run-Step 'python-pipeline' $py @('bindings/python/test_pipeline.py'))
    [void](Run-Step 'differential-corpus' $py @('benchmarks/differential_corpus.py','--json',"$logs\differential-corpus.json"))
    [void](Run-Step 'streaming-corpus' $py @('benchmarks/streaming_corpus.py','--json',"$logs\streaming-corpus.json"))
    [void](Run-Step 'batch-quick' $py @('benchmarks/benchmark_batch_api.py','--quick'))
    if((Run-Step 'node-dependencies' 'npm.cmd' @('install','--no-audit','--no-fund','--package-lock=false') "$source\bindings\nodejs") -eq 0){
        [void](Run-Step 'node-pipeline' 'node.exe' @('test_pipeline.js') "$source\bindings\nodejs")
    }
    [void](Run-Step 'csharp-build' 'dotnet.exe' @('build','bindings/csharp/Tacuda.Bindings.csproj','-c','Release','--nologo'))
    [void](Run-Step 'csharp-pipeline' 'dotnet.exe' @('run','--project','bindings/csharp/ConsoleExample','-c','Release','-f','net8.0','--','--pipeline'))
    [void](Run-Step 'csharp-tests' 'dotnet.exe' @('run','--project','bindings/csharp/ConsoleExample','-c','Release','-f','net8.0','--','--test'))
    nvidia-smi > "$logs\gpu-after.txt"
    Set-Content "$auditRoot\phase.txt" 'done'
    Set-Content "$auditRoot\completed.txt" ([DateTime]::UtcNow.ToString('o'))
} catch {
    $_ | Out-String | Set-Content "$logs\fatal.txt"
    Set-Content "$auditRoot\phase.txt" 'failed'
    Set-Content "$auditRoot\completed.txt" ([DateTime]::UtcNow.ToString('o'))
    exit 1
}

