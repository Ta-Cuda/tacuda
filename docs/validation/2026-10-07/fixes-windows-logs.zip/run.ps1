$ErrorActionPreference='Stop'
$root='J:\codex-audits\tacuda-fixes-20261007'
$source="$root\source"
$logs="$root\logs"
$prior='J:\codex-audits\tacuda-20261007-263f99b'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$results=New-Object System.Collections.Generic.List[object]
function Step([string]$Name,[string]$Exe,[string[]]$Arguments) {
 Set-Content "$root\phase.txt" $Name
 $start=[DateTime]::UtcNow
 & $Exe @Arguments *> "$logs\$Name.log"
 $code=$LASTEXITCODE
 $results.Add([pscustomobject]@{step=$Name;exitCode=$code;seconds=[Math]::Round(([DateTime]::UtcNow-$start).TotalSeconds,2)})
 $results | ConvertTo-Json -Depth 4 | Set-Content "$logs\results.json"
 if($code -ne 0){throw "$Name failed ($code)"}
}
try {
 Set-Location $source
 $py="$prior\venv-talib070\Scripts\python.exe"
 $env:PATH="$prior\venv-talib070\Scripts;$source\build;$env:PATH"
 $env:PYTHONPATH="$source\bindings\python"
 $env:PYTHONIOENCODING='utf-8'
 $env:TACUDA_LIBRARY="$source\build\tacuda.dll"
 $env:TACUDA_OPT_TALIB="$prior\talib-native\bin\ta-lib.dll"
 Step 'configure' 'cmake.exe' @('-S','.','-B','build','-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CUDA_ARCHITECTURES=86','-DBUILD_TESTING=ON',"-DPython3_EXECUTABLE=$py","-DCMAKE_CUDA_COMPILER=$env:CUDA_PATH/bin/nvcc.exe","-DCUDAToolkit_ROOT=$env:CUDA_PATH")
 Step 'build' 'cmake.exe' @('--build','build','-j','4')
 Step 'ctest' 'ctest.exe' @('--test-dir','build','--output-on-failure','--parallel','1','--timeout','180','--output-junit',"$logs\ctest.xml")
 Step 'python' $py @('bindings/python/test_pipeline.py')
 Step 'differential' $py @('benchmarks/differential_corpus.py','--json',"$logs\differential.json")
 Step 'streaming' $py @('benchmarks/streaming_corpus.py','--json',"$logs\streaming.json")
 Step 'node-install' 'npm.cmd' @('--prefix','bindings/nodejs','install','--no-audit','--no-fund','--package-lock=false')
 Step 'node' 'node.exe' @('bindings/nodejs/test_pipeline.js')
 Step 'csharp' 'dotnet.exe' @('run','--project','bindings/csharp/ConsoleExample','-c','Release','--','--pipeline')
 Get-FileHash "$source\build\tacuda.dll" | Format-List > "$logs\native-sha256.txt"
 Set-Content "$root\phase.txt" 'done'
} catch { $_ | Out-String | Set-Content "$logs\fatal.txt"; Set-Content "$root\phase.txt" 'failed' }
Set-Content "$root\completed.txt" ([DateTime]::UtcNow.ToString('o'))
