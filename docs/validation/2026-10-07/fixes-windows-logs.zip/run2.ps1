$ErrorActionPreference='Stop'
$root='J:\codex-audits\tacuda-fixes-20261007'
$source="$root\source"
$logs="$root\logs"
$prior='J:\codex-audits\tacuda-20261007-263f99b'
$results=New-Object System.Collections.Generic.List[object]
function Step([string]$Name,[string]$Exe,[string[]]$Arguments) {
 Set-Content "$root\phase2.txt" $Name
 $start=[DateTime]::UtcNow
 $ErrorActionPreference='Continue'
 & $Exe @Arguments *> "$logs\$Name.log"
 $code=$LASTEXITCODE
 $ErrorActionPreference='Stop'
 $results.Add([pscustomobject]@{step=$Name;exitCode=$code;seconds=[Math]::Round(([DateTime]::UtcNow-$start).TotalSeconds,2)})
 $results | ConvertTo-Json -Depth 4 | Set-Content "$logs\results2.json"
 if($code -ne 0){throw "$Name failed ($code)"}
}
try {
 Set-Location $source
 $py="$prior\venv-talib070\Scripts\python.exe"
 $env:PATH="$prior\venv-talib070\Scripts;$source\build;$env:PATH"
 $env:PYTHONPATH="$source\bindings\python"
 $env:PYTHONIOENCODING='utf-8'
 $env:TACUDA_LIBRARY="$source\build\tacuda.dll"
 $env:TACUDA_OPT_TALIB="$prior\talib-native\bin\ta-lib.dll"
 Step 'configure-final' 'cmake.exe' @('-S','.','-B','build','-DTACUDA_ENABLE_ASAN_TEST=ON')
 Step 'build-final' 'cmake.exe' @('--build','build','-j','4')
 Step 'focused' 'ctest.exe' @('--test-dir','build','-R','TacudaStream|release_versions|bindings_|stream_lifetime','--output-on-failure','--output-junit',"$logs\focused.xml")
 Step 'exports-final' $py @('scripts/check_dll_exports.py','build/tacuda.dll')
 Step 'python-final' $py @('bindings/python/test_pipeline.py')
 Step 'node-final' 'node.exe' @('bindings/nodejs/test_pipeline.js')
 Step 'csharp-final' 'dotnet.exe' @('run','--project','bindings/csharp/ConsoleExample','-c','Release','--','--pipeline')
 Step 'csharp-bindings' 'dotnet.exe' @('run','--project','bindings/csharp/ConsoleExample','-c','Release','--','--test')
 Step 'vector-math' $py @('benchmarks/benchmark_vector_math.py','--json',"$logs\vector-math.json")
 Step 'latency-build' 'cl.exe' @('/nologo','/O2','/EHsc','/std:c++17','/Iinclude',"/I$env:CUDA_PATH/include",'benchmarks/bench_stream_latency.cpp','build/tacuda.lib','/Fe:build/bench-stream-latency.exe')
 Step 'latency' "$source\build\bench-stream-latency.exe" @()
 Step 'portfolio-build' 'cl.exe' @('/nologo','/O2','/EHsc','/std:c++17','/Iinclude',"/I$env:CUDA_PATH/include",'benchmarks/bench_stream_portfolio.cpp','build/tacuda.lib','/Fe:build/bench-stream-portfolio.exe')
 Step 'portfolio' "$source\build\bench-stream-portfolio.exe" @()
 Get-FileHash "$source\build\tacuda.dll" | Format-List > "$logs\native-sha256-final.txt"
 nvidia-smi > "$logs\gpu-final.txt"
 Set-Content "$root\phase2.txt" 'done'
} catch { $_ | Out-String | Set-Content "$logs\fatal2.txt"; Set-Content "$root\phase2.txt" 'failed' }
Set-Content "$root\completed2.txt" ([DateTime]::UtcNow.ToString('o'))
